package example;

public class DataType {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		byte b=100;
		short s=2005;		
		int i=554656446;
		long l=5663566655555l; //ending with l
		System.out.println(b);
		System.out.println(s);
		System.out.println(i);
		System.out.println(l);
		
		
		float f=555.66f; //ending with f
		double d =5456665.34333;
		System.out.println(f);
		System.out.println(d);
		
		boolean bb = true;
		System.out.println(bb);
		
		char c ='%';
		System.out.println(c);
		
		
		
	}

}
