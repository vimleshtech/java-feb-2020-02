package example;
import java.util.Scanner;

public class Operator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i,j;
		i=0;
		j=0;
		
		System.out.println(i++);//0 
		System.out.println(++j);//1
		
		System.out.println(i);//1
		System.out.println(j);//1
		
		//System.out.print("hi"); //dont changle line
		System.out.println("hi");  //new line
		System.out.print("hello");

		
		//input 
		Scanner s=new Scanner(System.in); //create an object of class Scanner 
		int a,b,c;
		
		System.out.println("enter data of a and b");
		a = s.nextInt();
		b = s.nextInt();
		
		c=a +b;
		System.out.println(c);
		
		int rollnumber, marks, phone;
		rollnumber=1;
		marks=0;
		phone=3;
		 
		
		System.out.println(rollnumber);
		System.out.println(marks);
		System.out.println(phone);
		System.out.println("hi");
	

	
		
		int roll;
		String name;
		
		System.out.println("enter data of roll, marks and phone , name");
		roll = s.nextInt();
		marks = s.nextInt();
		phone = s.nextInt();
		name = s.next();
		
			System.out.println(roll);
			System.out.println(marks);
			System.out.println(phone);
			System.out.println(name);
	}
}