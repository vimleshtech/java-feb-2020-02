package tax;

public class Hello {

	public static void main(String[] ar) {
		
		int a,b,c;
		a =44;
		b =555;
				
		//expression 
		c =a+b;
		
		//output
		System.out.println("sum of two values "+c);
		
		
	}
}
